package com.airomatic.banhammer;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.Date;

/**
 * BanHammer
 * Author: airomatic
 *
 * Announces bans server-wide in purple text and keeps a running
 * total of how many bans have ever been issued, e.g.:
 *
 *   [Server] AlotaPagina was hit with the banhammer! (1000 bans)
 */
public class BanHammerPlugin extends JavaPlugin implements CommandExecutor {

    private FileConfiguration config;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        config = getConfig();

        if (!config.contains("total-bans")) {
            config.set("total-bans", 0);
        }
        if (!config.contains("broadcast-message")) {
            config.set("broadcast-message", "&d[Server] %player% was hit with the banhammer! (%count% bans)");
        }
        saveConfig();

        if (getCommand("ban") != null) {
            getCommand("ban").setExecutor(this);
        }

        getLogger().info("BanHammer enabled by airomatic! Current ban count: " + config.getInt("total-bans", 0));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("ban")) {
            return false;
        }

        if (args.length < 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /ban <player> [reason]");
            return true;
        }

        String targetName = args[0];
        String reason = args.length > 1
                ? String.join(" ", Arrays.copyOfRange(args, 1, args.length))
                : "Banned by an operator";

        // Register the ban with the server's ban list
        Bukkit.getBanList(BanList.Type.NAME).addBan(targetName, reason, (Date) null, sender.getName());

        // Kick them immediately if they're online
        Player target = Bukkit.getPlayerExact(targetName);
        if (target != null && target.isOnline()) {
            target.kickPlayer(ChatColor.RED + "You have been banned!\n" + ChatColor.GRAY + reason);
        }

        // Bump the persistent counter
        int total = config.getInt("total-bans", 0) + 1;
        config.set("total-bans", total);
        saveConfig();

        // Build and broadcast the purple announcement
        String template = config.getString("broadcast-message",
                "&d[Server] %player% was hit with the banhammer! (%count% bans)");
        String message = ChatColor.translateAlternateColorCodes('&', template)
                .replace("%player%", targetName)
                .replace("%count%", String.valueOf(total));

        Bukkit.broadcastMessage(message);

        return true;
    }
}
