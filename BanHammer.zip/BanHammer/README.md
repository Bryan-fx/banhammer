# BanHammer
by **airomatic**

A Paper/Spigot plugin that announces bans server-wide in purple chat text
with a persistent, ever-increasing ban counter — styled like:

    [Server] AlotaPagina was hit with the banhammer! (1000 bans)

## Features
- Custom `/ban <player> [reason]` command that bans + kicks the target
- Broadcasts the ban in **light purple** to the whole server
- Tracks a running total of all bans ever issued, saved in `config.yml`
- Message format is editable in `config.yml` via `%player%` and `%count%`

## Building
Requires Java 17+ and Maven:

```
mvn clean package
```

The compiled plugin will be at `target/BanHammer.jar`.

## Installing
1. Drop `BanHammer.jar` into your server's `plugins/` folder.
2. Restart or reload the server.
3. Use `/ban <player> [reason]` (permission: `banhammer.ban`, default: op).

## Config
`plugins/BanHammer/config.yml`:

```yaml
total-bans: 0
broadcast-message: "&d[Server] %player% was hit with the banhammer! (%count% bans)"
```

Edit `total-bans` to set a custom starting number, or change the message
format/color codes to taste.
